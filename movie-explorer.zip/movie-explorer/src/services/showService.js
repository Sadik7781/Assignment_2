// Centralized TVMaze API access.
// Keeping every fetch call in one module means components/hooks never
// talk to `fetch` directly — mirrors the service-layer pattern used
// across the bootcamp's Next-Level apps (e.g. the weather app's api layer).

const BASE_URL = 'https://api.tvmaze.com'

async function handleResponse(response) {
  if (!response.ok) {
    throw new Error(`Request failed with status ${response.status}`)
  }
  return response.json()
}

/**
 * Fetch all shows (paginated by TVMaze, page 0 = most popular slice).
 * Used for the default "browse" grid when there is no search query.
 */
export async function getAllShows() {
  const response = await fetch(`${BASE_URL}/shows?page=0`)
  return handleResponse(response)
}

/**
 * Search shows by title.
 * TVMaze wraps each result as `{ score, show }`, so we normalize
 * it to a flat array of show objects for the rest of the app.
 */
export async function searchShows(query) {
  const response = await fetch(
    `${BASE_URL}/search/shows?q=${encodeURIComponent(query)}`,
  )
  const results = await handleResponse(response)
  return results.map((result) => result.show)
}

/**
 * Fetch full details (including cast) for a single show, used by the modal.
 */
export async function getShowById(id) {
  const response = await fetch(`${BASE_URL}/shows/${id}?embed=cast`)
  return handleResponse(response)
}
