import { useState } from 'react'
import SearchBar from '../components/SearchBar'
import MovieGrid from '../components/MovieGrid'
import MovieModal from '../components/MovieModal'
import Loader from '../components/Loader'
import EmptyState from '../components/EmptyState'
import { useDebounce } from '../hooks/useDebounce'
import { useShows } from '../hooks/useShows'

export default function Movies() {
  const [searchTerm, setSearchTerm] = useState('')
  const [selectedShow, setSelectedShow] = useState(null)

  const debouncedSearchTerm = useDebounce(searchTerm, 400)
  const { shows, isLoading, error } = useShows(debouncedSearchTerm)

  return (
    <main className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="mb-8 text-center sm:text-left">
        <h1 className="font-display text-4xl text-white">Browse Movies</h1>
        <p className="mt-2 text-sm text-slate-400">
          Search by title or scroll through what's trending.
        </p>
      </div>

      <div className="mb-10">
        <SearchBar value={searchTerm} onChange={setSearchTerm} />
      </div>

      {isLoading && <Loader />}

      {!isLoading && error && (
        <EmptyState
          icon="⚠️"
          title="Something went wrong"
          message={error}
        />
      )}

      {!isLoading && !error && shows.length === 0 && (
        <EmptyState
          title="No results"
          message={`We couldn't find anything for "${debouncedSearchTerm}".`}
        />
      )}

      {!isLoading && !error && shows.length > 0 && (
        <MovieGrid shows={shows} onViewDetails={setSelectedShow} />
      )}

      {selectedShow && (
        <MovieModal show={selectedShow} onClose={() => setSelectedShow(null)} />
      )}
    </main>
  )
}
