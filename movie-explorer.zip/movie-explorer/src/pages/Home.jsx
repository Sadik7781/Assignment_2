import HeroBanner from '../components/HeroBanner'

export default function Home() {
  return (
    <main>
      <HeroBanner />

      <section className="mx-auto max-w-5xl px-4 py-16 text-center sm:py-20">
        <h2 className="font-display text-3xl text-white sm:text-4xl">
          Why MovieExplorer?
        </h2>
        <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-3">
          <div className="rounded-2xl border border-white/5 bg-cinema-800 p-6">
            <div className="text-3xl">🔍</div>
            <h3 className="mt-3 font-semibold text-white">Powerful Search</h3>
            <p className="mt-2 text-sm text-slate-400">
              Instantly search thousands of titles by name.
            </p>
          </div>
          <div className="rounded-2xl border border-white/5 bg-cinema-800 p-6">
            <div className="text-3xl">🎞️</div>
            <h3 className="mt-3 font-semibold text-white">Rich Details</h3>
            <p className="mt-2 text-sm text-slate-400">
              Ratings, genres, overviews and more in one click.
            </p>
          </div>
          <div className="rounded-2xl border border-white/5 bg-cinema-800 p-6">
            <div className="text-3xl">📱</div>
            <h3 className="mt-3 font-semibold text-white">Fully Responsive</h3>
            <p className="mt-2 text-sm text-slate-400">
              A seamless experience on mobile, tablet and desktop.
            </p>
          </div>
        </div>
      </section>
    </main>
  )
}
