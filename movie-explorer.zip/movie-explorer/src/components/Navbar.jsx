import { NavLink } from 'react-router-dom'

const navLinkClasses = ({ isActive }) =>
  `text-sm font-medium transition-colors ${
    isActive ? 'text-accent-500' : 'text-slate-300 hover:text-white'
  }`

export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/5 bg-cinema-950/80 backdrop-blur-md">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 sm:px-6">
        <NavLink to="/" className="flex items-center gap-2">
          <span className="text-2xl">🎬</span>
          <span className="font-display text-2xl tracking-wide text-white">
            Movie<span className="text-accent-500">Explorer</span>
          </span>
        </NavLink>

        <div className="hidden items-center gap-8 sm:flex">
          <NavLink to="/" className={navLinkClasses} end>
            Home
          </NavLink>
          <NavLink to="/movies" className={navLinkClasses}>
            Movies
          </NavLink>
        </div>

        <NavLink
          to="/movies"
          className="rounded-full bg-accent-500 px-4 py-2 text-sm font-semibold text-cinema-950 transition hover:bg-accent-600"
        >
          Movies
        </NavLink>
      </nav>
    </header>
  )
}
