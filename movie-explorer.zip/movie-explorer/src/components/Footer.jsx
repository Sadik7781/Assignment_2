export default function Footer() {
  const year = new Date().getFullYear()

  return (
    <footer className="border-t border-white/5 bg-cinema-900">
      <div className="mx-auto flex max-w-6xl flex-col items-center gap-3 px-4 py-8 text-center sm:flex-row sm:justify-between sm:text-left">
        <div className="flex items-center gap-2">
          <span className="text-xl">🎬</span>
          <span className="font-display text-lg tracking-wide text-white">
            Movie<span className="text-accent-500">Explorer</span>
          </span>
        </div>

        <p className="text-sm text-slate-400">
          &copy; {year} MovieExplorer. Built for the React assignment.
        </p>

        <div className="flex items-center gap-4 text-sm text-slate-400">
          <a
            href="https://github.com"
            target="_blank"
            rel="noreferrer"
            className="transition hover:text-accent-500"
          >
            GitHub
          </a>
          <a
            href="https://www.tvmaze.com/api"
            target="_blank"
            rel="noreferrer"
            className="transition hover:text-accent-500"
          >
            Data by TVMaze
          </a>
        </div>
      </div>
    </footer>
  )
}
