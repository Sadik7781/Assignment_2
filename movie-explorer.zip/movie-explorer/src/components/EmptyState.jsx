export default function EmptyState({
  title = 'No movies found',
  message = 'Try searching for a different title.',
  icon = '🎥',
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-white/10 py-24 text-center">
      <span className="text-4xl">{icon}</span>
      <h3 className="text-lg font-semibold text-white">{title}</h3>
      <p className="max-w-xs text-sm text-slate-400">{message}</p>
    </div>
  )
}
