function stripHtml(html) {
  if (!html) return ''
  return html.replace(/<[^>]*>/g, '')
}

export default function MovieCard({ show, onViewDetails }) {
  const posterUrl =
    show.image?.medium || show.image?.original || '/movie-icon.svg'
  const year = show.premiered ? show.premiered.slice(0, 4) : 'N/A'
  const rating = show.rating?.average ? show.rating.average.toFixed(1) : 'N/A'

  return (
    <article className="group flex flex-col overflow-hidden rounded-2xl border border-white/5 bg-cinema-800 shadow-lg shadow-black/20 transition duration-300 hover:-translate-y-1 hover:border-accent-500/30 hover:shadow-accent-500/10">
      <div className="relative aspect-[2/3] w-full overflow-hidden bg-cinema-700">
        <img
          src={posterUrl}
          alt={show.name}
          loading="lazy"
          className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
        />
        <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-black/70 to-transparent" />
      </div>

      <div className="flex flex-1 flex-col gap-2 p-4">
        <h3 className="line-clamp-1 text-base font-semibold text-white">
          {show.name}
        </h3>

        <p className="line-clamp-3 text-xs text-slate-400">
          {stripHtml(show.summary) || 'No description available.'}
        </p>

        <div className="mt-auto flex items-center gap-3 pt-2 text-sm text-slate-300">
          <span>⭐ {rating}</span>
          <span aria-hidden="true">•</span>
          <span>📅 {year}</span>
        </div>

        <button
          type="button"
          onClick={() => onViewDetails(show)}
          className="mt-3 w-full rounded-xl bg-accent-500/10 py-2 text-sm font-semibold text-accent-500 transition hover:bg-accent-500 hover:text-cinema-950"
        >
          See Details
        </button>
      </div>
    </article>
  )
}
