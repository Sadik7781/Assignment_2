export default function Loader({ label = 'Loading movies...' }) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-24 text-slate-400">
      <div className="h-10 w-10 animate-spin rounded-full border-4 border-accent-500/20 border-t-accent-500" />
      <p className="text-sm">{label}</p>
    </div>
  )
}
