import { Link } from 'react-router-dom'

export default function HeroBanner() {
  return (
    <section className="relative overflow-hidden">
      {/* Background gradient + subtle film-grain feel */}
      <div className="absolute inset-0 bg-gradient-to-br from-cinema-900 via-cinema-950 to-black" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(245,197,24,0.12),transparent_45%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_80%_60%,rgba(88,28,135,0.25),transparent_45%)]" />

      <div className="relative mx-auto flex max-w-4xl flex-col items-center px-4 py-24 text-center sm:py-32">
        <span className="mb-4 rounded-full border border-accent-500/30 bg-accent-500/10 px-4 py-1 text-xs font-semibold uppercase tracking-widest text-accent-500">
          Discover something new tonight
        </span>

        <h1 className="font-display text-5xl leading-tight text-white sm:text-7xl">
          Discover Movies &amp; Shows
        </h1>

        <p className="mt-6 max-w-xl text-base text-slate-300 sm:text-lg">
          Explore and discover your favorite movies and TV shows from around
          the world — search by title and dive into the details.
        </p>

        <Link
          to="/movies"
          className="mt-10 inline-flex items-center gap-2 rounded-full bg-accent-500 px-8 py-3 text-base font-semibold text-cinema-950 shadow-lg shadow-accent-500/20 transition hover:-translate-y-0.5 hover:bg-accent-600"
        >
          Explore Now
          <span aria-hidden="true">&rarr;</span>
        </Link>
      </div>
    </section>
  )
}
