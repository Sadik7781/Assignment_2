import { useEffect } from 'react'

function stripHtml(html) {
  if (!html) return 'No overview available for this title.'
  return html.replace(/<[^>]*>/g, '')
}

export default function MovieModal({ show, onClose }) {
  // Close on Escape key
  useEffect(() => {
    function handleKeyDown(event) {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [onClose])

  if (!show) return null

  const backdropUrl = show.image?.original || show.image?.medium
  const rating = show.rating?.average ? show.rating.average.toFixed(1) : 'N/A'
  const genres = show.genres?.length ? show.genres.join(', ') : 'N/A'

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={show.name}
        onClick={(event) => event.stopPropagation()}
        className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-white/10 bg-cinema-800 shadow-2xl"
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close"
          className="absolute right-4 top-4 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-black/50 text-white transition hover:bg-accent-500 hover:text-cinema-950"
        >
          ✕
        </button>

        <div className="relative h-56 w-full bg-cinema-700 sm:h-72">
          {backdropUrl ? (
            <img
              src={backdropUrl}
              alt={show.name}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-5xl">
              🎬
            </div>
          )}
          <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-cinema-800 to-transparent" />
        </div>

        <div className="space-y-4 p-6">
          <h2 className="font-display text-3xl text-white">{show.name}</h2>

          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-slate-300">
            <span>⭐ Rating: {rating}</span>
            <span>📅 Release: {show.premiered || 'N/A'}</span>
            <span>🎭 Genre: {genres}</span>
            {show.network?.name && <span>📺 Network: {show.network.name}</span>}
            {show.language && <span>🌐 Language: {show.language}</span>}
          </div>

          <div>
            <h3 className="mb-1 text-sm font-semibold uppercase tracking-wide text-accent-500">
              Overview
            </h3>
            <p className="text-sm leading-relaxed text-slate-300">
              {stripHtml(show.summary)}
            </p>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="button"
              onClick={onClose}
              className="rounded-xl bg-white/5 px-5 py-2 text-sm font-semibold text-white transition hover:bg-white/10"
            >
              ❌ Close
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
