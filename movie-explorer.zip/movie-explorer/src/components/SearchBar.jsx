export default function SearchBar({ value, onChange }) {
  return (
    <div className="relative w-full">
      <span className="pointer-events-none absolute inset-y-0 left-4 flex items-center text-slate-400">
        🔍
      </span>
      <input
        type="text"
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder="Search for a movie or show..."
        className="w-full rounded-2xl border border-white/10 bg-cinema-800 py-4 pl-12 pr-4 text-base text-white placeholder:text-slate-500 outline-none ring-accent-500/40 transition focus:border-accent-500/50 focus:ring-2"
      />
    </div>
  )
}
