import { useEffect, useState } from 'react'
import { getAllShows, searchShows } from '../services/showService'

/**
 * Encapsulates fetching + loading + error state for the movie grid.
 * If `query` is empty, loads the general "browse all" list.
 * Otherwise hits the search endpoint.
 */
export function useShows(query) {
  const [shows, setShows] = useState([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    let isCancelled = false

    async function fetchShows() {
      setIsLoading(true)
      setError(null)
      try {
        const data = query.trim()
          ? await searchShows(query.trim())
          : await getAllShows()

        if (!isCancelled) {
          setShows(data)
        }
      } catch (err) {
        if (!isCancelled) {
          setError(err.message || 'Something went wrong while fetching shows.')
          setShows([])
        }
      } finally {
        if (!isCancelled) {
          setIsLoading(false)
        }
      }
    }

    fetchShows()

    return () => {
      isCancelled = true
    }
  }, [query])

  return { shows, isLoading, error }
}
