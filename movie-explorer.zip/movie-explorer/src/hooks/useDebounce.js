import { useEffect, useState } from 'react'

/**
 * Returns a debounced copy of `value` that only updates
 * after `delay` ms of no further changes. Used so the search
 * bar doesn't fire an API request on every keystroke.
 */
export function useDebounce(value, delay = 400) {
  const [debouncedValue, setDebouncedValue] = useState(value)

  useEffect(() => {
    const timeoutId = setTimeout(() => setDebouncedValue(value), delay)
    return () => clearTimeout(timeoutId)
  }, [value, delay])

  return debouncedValue
}
